### DIN UPPGIFT: Besvara fråga 1 och 2 i denna md-fil. Fråga 3 behöver du inte besvara, utan den utför du.


1. Vad är Typescript och och hur skiljer det sig från Javascript? / 2 poäng
2. Vad är fördelen att använda sig av Typescript? Finns det nackdelar? / 2 poäng
3. Initiera ett vanilla TS-projekt så att du kan kompilera 
 Typescript i alla ts-filer i en och samma mapp (src). De kompilerade filerna ska hamna i en dist-mapp. / 2 poäng