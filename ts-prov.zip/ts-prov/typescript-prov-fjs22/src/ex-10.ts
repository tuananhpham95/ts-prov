// DIN UPPGIFT: Utför fråga 1-3 med kodexempel i Typescript / 3 poäng


// 1. Ge ett exempel på en funktion med en generiskt typ.
const reverseArr = <T>(arr: T[]): T[] => {
    return arr.reverse();
  };



// 2. Ge ett exempel på en funktion med två generiska typer.

const makePair = <K, V>(key: K, value: V): { key: K; value: V } => {
    return { key, value };
  };

// 3. Ge ett exempel på ett interface med en generisk typ.
interface Box<T> {
    item: T;
  }
