### DIN UPPGIFT: Besvara följande fråga i denna md-fil / 3 poäng

Beskriv vad generics är i TypeScript och varför de är användbara.
Hur skiljer sig generics från att använda "any" i TypeScript?

Generics i TypeScript tillåter skapande av återanvändbara komponenter och funktioner som kan hantera olika datatyper samtidigt, bibehåller typsäkerheten och ökar kodens flexibilitet. Any tillhör också Generics type men skillnaden är att typen 'any' kan vara vilken typ som helst.
