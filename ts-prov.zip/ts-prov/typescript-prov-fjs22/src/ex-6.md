###  DIN UPPGIFT: Besvara följande fråga i denna md-fil / 3 poäng

I Typescript kan både type och interfaces användas för att skapa egna sammansatta typer. I många fall kan man använda antingen type eller interfaces, men det finns också skillnader. Redogör för dem och visa med kodexempel. 

type : används för att skapa en alias för en specifik typ, inklusive unioner, intersections och andra komplexa typer.
Kan användas för olika datatyper och tillåter unions, intersections och typutvidgning.
type Person = {
    name: string;
    age: number;
};

interface:Används för att definiera strukturer för objekt med metoder, egenskaper och arv.Kan utökas eller implementeras av andra interfaces.Tillåter merge av flera deklarationer med samma namn. 
interface Person {
    name: string;
    age: number;
}

Skillnader:
interface tillåter arv och merge, medan type möjliggör unions, intersections och mer flexibilitet för komplexa typer.
