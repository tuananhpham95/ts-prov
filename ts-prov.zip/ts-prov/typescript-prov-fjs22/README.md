# Instruktioner prov

**Tid 9.30 - 12.00 torsdag 2 november i sal 5.**

**Totalpoäng 45 poäng varav 25 poäng godkänd och 40 poäng Väl godkänd.**

**Hjälpmedel:** Google, Typescript documentation, Zod dokumentation

**Obs!** Man får inte använda AI-verktyg som Chat GPT och Github Co-pilot eller liknande. 
**Vid misstanke om fusk så avbryts provet för vederbörande.**

**Instruktioner:**
Läraren ger repot vid uppstart. I ```src``` finns det 13 uppgifter. Följ instruktionerna i varje fil. 

Om du vill språkgranska din text i .md-filerna går det bra att kopiera in i ex Google docs, men lägg tillbaka texten i filen när du är färdig.

När man är klar pushar man sitt egna repo och lämnar in länken under uppgiften "Prov Typescript torsdag 2 november" i Canvas.
Kom ihåg att du kan få delpoäng i en uppgift, d.v.s lämna även in icke fullständiga uppgifter!
